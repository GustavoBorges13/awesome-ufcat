#ifndef KB_H
#define KB_H
#include "types.h"
#include "system.h"
#include "string.h"

// Função para traduzir os códigos de rastreamento de teclado para ASCII
string readStr();

#endif
