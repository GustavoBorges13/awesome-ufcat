#ifndef SCREEN_H
#define SCREEN_H

#include "types.h"
#include "system.h"
#include "string.h"

extern int32 cursorX;
extern int32 cursorY;

void printch (char c);
void print(string ch);

#endif

