#ifndef STRING_H
#define STRING_H
#include "types.h"

// Função para calcular o comprimento de uma string
uint16 strlength(string ch);

// Função para comparar duas strings
uint8 strEql(string ch1, string ch2);

#endif
