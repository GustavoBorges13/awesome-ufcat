#include "basic/include/screen.h"
void kmain() {
	clearScreen();
    	print(": : Digite algo:");
    
    	// Chama a função readStr para obter a entrada do usuário
    	updateCursor();
    	string userInput = readStr();

   	// Limpa a tela e imprime a string lida
    	clearScreen();
    	print(": : Voce digitou:");
    	print(userInput);
    	print("\n\napos ter pressionado ESC, o programa foi encerrado...");
}

