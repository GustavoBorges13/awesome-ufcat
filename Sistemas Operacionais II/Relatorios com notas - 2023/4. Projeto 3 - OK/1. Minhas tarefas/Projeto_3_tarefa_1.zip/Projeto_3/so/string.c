#include "basic/include/string.h"

// Função para calcular o comprimento de uma string
uint16 strlength(string ch) {
    uint16 i = 1;
    while(ch[i++]);
    return --i;
}

// Função para comparar duas strings
uint8 strEql(string ch1, string ch2) {
    uint8 result = 1;
    uint8 size = strlength(ch1);
    // Verifica se o tamanho da segunda string é diferente do tamanho da primeira
    if (size != strlength(ch2))
        result = 0;
    else {
        uint8 i = 0;
        // Itera sobre os caracteres das duas strings
        for(i; i <= size; i++)
            // Compara os caracteres correspondentes das duas strings
            if (ch1[i] != ch2[i])
                result = 0;
    }
    return result;
}
