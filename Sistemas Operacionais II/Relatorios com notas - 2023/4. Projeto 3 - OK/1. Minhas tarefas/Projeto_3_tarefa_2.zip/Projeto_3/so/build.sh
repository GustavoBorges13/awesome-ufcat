#!/bin/sh
nasm -f elf32 kernel.asm -o kasm.o
gcc -m32 -c -w kernel.c -o kc.o -ffreestanding
gcc -m32 -c -w screen.c -o screen.o -ffreestanding
gcc -m32 -c -w string.c -o string.o -ffreestanding
gcc -m32 -c -w system.c -o system.o -ffreestanding
gcc -m32 -c -w kb.c -o kb.o -ffreestanding
gcc -m32 -c -w util.c -o util.o -ffreestanding
gcc -m32 -c -w idt.c -o idt.o -ffreestanding
gcc -m32 -c -w isr.c -o isr.o -ffreestanding 
ld -m elf_i386 -T link.ld -o basic/boot/kernel.bin kasm.o kc.o screen.o string.o system.o kb.o util.o idt.o isr.o
