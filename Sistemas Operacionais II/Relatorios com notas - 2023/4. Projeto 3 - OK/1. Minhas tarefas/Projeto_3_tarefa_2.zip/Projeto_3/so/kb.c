#include "basic/include/kb.h"
#include "basic/include/idt.h"

string readStr() {
	char buff[256];
	string buffstr = buff;
	uint8 i = 0;
	uint8 reading = 1;
	while(reading){
		//0x64 = endereço da porta de status do controlador
		if(inportb(0x64) & 0x1){
		      // 0x60 = endereço da porta de dados do controlador
		      switch(inportb(0x60)){
			case 1: //ESC
				clearScreen();  // Limpa a tela
    				i = 0;  // Reinicia o índice da string
    				break;
			case 2: //1
                   		printch('1');
                    		buffstr[i] = '1';
                    		i++;
                    		break;
                    	case 3: //2
				printch('2');
				buffstr[i] = '2';
				i++;
				break;
			case 4: //3
				printch('3');
				buffstr[i] = '3';
				i++;
				break;
			case 5: //4
				printch('4');
				buffstr[i] = '4';
				i++;
				break;
			case 6: //5
				printch('5');
				buffstr[i] = '5';
				i++;
				break;
			case 7: //6
				printch('6');
				buffstr[i] = '6';
				i++;
				break;
			case 8: //7
				printch('7');
				buffstr[i] = '7';
				i++;
				break;
			case 9: //8
				printch('8');
				buffstr[i] = '8';
				i++;
				break;
			case 10: //9
				printch('9');
				buffstr[i] = '9';
				i++;
				break;
			case 11: //0
				printch('0');
				buffstr[i] = '0';
				i++;
				break;
			case 12: //-
				printch('-');
				buffstr[i] = '-';
				i++;
				break;
			case 13: //=
				printch('=');
				buffstr[i] = '=';
				i++;
				break;
			case 14: // BACKSPACE
				// Imprime char de controle '\b' para apagar na tela
    				printch('\b'); 
    				// Verifica se há chars na string antes de retroceder
    				if (i > 0) {
					i--; // Retrocede indice na string
	       				buffstr[i] = 0;   // Remove último char ao atribuir zero à posição atual na string
				}
				break;
			case 15: //TAB
				printch('\t');  // Imprime o caractere de tabulação
   				buffstr[i] = '\t'; // Armazena o caractere na string
   				i++;
    				break;
			case 16: //q
				printch('q');
				buffstr[i] = 'q';
				i++;
				break;
			case 17: //w
				printch('w');
				buffstr[i] = 'w';
				i++;
				break;
			case 18: //e
				printch('e');
				buffstr[i] = 'e';
				i++;
				break;
			case 19: //r
				printch('r');
				buffstr[i] = 'r';
				i++;
				break;

			case 20: //t
				printch('t');
				buffstr[i] = 't';
				i++;
				break;
			case 21: //y
				printch('y');
				buffstr[i] = 'y';
				i++;
				break;
			case 22: //u
				printch('u');
				buffstr[i] = 'u';
				i++;
				break;
			case 23: //i
				printch('i');
				buffstr[i] = 'i';
				i++;
				break;
			case 24: //o
				printch('o');
				buffstr[i] = 'o';
				i++;
				break;
			case 25: //p
				printch('p');
				buffstr[i] = 'p';
				i++;
				break;
			case 26: // [
    				printch((char)91);  // Código ASCII para '['
    				buffstr[i] = '[';
   				i++;
    				break;
    			case 27: // ]
    				printch((char)93);  // Código ASCII para ']'
    				buffstr[i] = ']';
   				i++;
    				break;
			case 28: //ENTER
				printch((char)13);  // Imprime o caractere "Enter"
				buffstr[i] = (char)13;  // Armazena "Enter" no buffer
				reading = 0;    // Encerra a leitura/loop
   				break;
			case 29: //CTRL
				//0x80 = usada para verificar se uma tecla foi liberada.
   				if (inportb(0x60) & 0x80) {
        				// Se a tecla 'Ctrl' foi liberada
        				print("Ctrl Released");
   				} else {
        				// Se a tecla 'Ctrl' foi pressionada
        				print("Ctrl Pressed");
    				}
  				break;
			case 30: //a
				printch('a');
				buffstr[i] = 'a';
				i++;
				break;
			case 31: //s
				printch('s');
				buffstr[i] = 's';
				i++;
				break;
			case 32: //d
				printch('d');
				buffstr[i] = 'd';
				i++;
				break;
			case 33: //f
				printch('f');
				buffstr[i] = 'f';
				i++;
				break;
			case 34: //g
				printch('g');
				buffstr[i] = 'g';
				i++;
				break;
			case 35: //h
				printch('h');
				buffstr[i] = 'h';
				i++;
				break;
			case 36: //j
				printch('j');
				buffstr[i] = 'j';
				i++;
				break;
			case 37: //k
				printch('k');
				buffstr[i] = 'k';
				i++;
				break;
			case 38: //l
				printch('l');
				buffstr[i] = 'l';
				i++;
				break;
			case 39: //;
				printch(';');
				buffstr[i] = ';';
				i++;
				break;
			case 40: // '
				printch('\'');
				buffstr[i] = '\'';
				i++;
				break;
			case 41: // `
				printch('`');
				buffstr[i] = '`';
				i++;
				break;
			case 42: //LSHIFT
 				if (inportb(0x60) & 0x80) {
        				// Se a tecla 'Shift' foi liberada
        				print("LShift Released");
    				} else {
        				// Se a tecla 'Shift' foi pressionada
       					print("LShift Pressed");
    				}
   				break;
			case 43: // \
				printch((char)92);
				buffstr[i] = (char)92;
				i++;
				break;
			case 44: //z
				printch('z');
				buffstr[i] = 'z';
				i++;
				break;
			case 45: //x
				printch('x');
				buffstr[i] = 'x';
				i++;
				break;
			case 46: //c
				printch('c');
				buffstr[i] = 'c';
				i++;
				break;
			case 47: //v
				printch('v');
				buffstr[i] = 'v';
				i++;
				break;
			case 48: //b
				printch('b');
				buffstr[i] = 'b';
				i++;
				break;
			case 49: //n
				printch('n');
				buffstr[i] = 'n';
				i++;
				break;
			case 50: //m
				printch('m');
				buffstr[i] = 'm';
				i++;
				break;
			case 51: // ,
    				printch(',');
    				buffstr[i] = ',';
    				i++;
    				break;
			case 52: // .
				printch('.');
				buffstr[i] = '.';
				i++;
				break;
			case 53: // /
				printch('/');
				buffstr[i] = '/';
				i++;
				break;
			case 54: // RShift
    				if (inportb(0x60) & 0x80) {
        				// Se a tecla 'RShift' foi liberada
        				print("RShift Released");
    				} else {
        				// Se a tecla 'RShift' foi pressionada
        				print("RShift Pressed");
    				}
    				break;
			case 55: // PRINTSCREEN - PrtSc
    				// Tecla 'PrtSc'
    				print("PrtSc");
    				break;			
			case 56: // ALT
    				if (inportb(0x60) & 0x80) {
        				// Se a tecla 'Alt' foi liberada
        				print("Alt Released");
    				} else {
        				// Se a tecla 'Alt' foi pressionada
        				print("Alt Pressed");
    				}
    				break;
			case 57: // SPACE
				// Tecla 'Space'
    				printch(' '); // Adiciona um espaço
    				buffstr[i] = ' ';
   				i++;
    				break;
			}
		}
	}
	buffstr[i] = 0;
	return buffstr;
}


