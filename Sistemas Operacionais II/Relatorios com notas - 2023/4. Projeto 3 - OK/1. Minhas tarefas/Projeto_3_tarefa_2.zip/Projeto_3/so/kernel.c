#include "basic/include/idt.h"
#include "basic/include/isr.h"
#include "basic/include/screen.h"

void keyboard_handler() {
    // aqui sera lidado com a interrupção do teclado 
    // ler o scancode do teclado por exemplo
}

void kmain() {
    // Configuração inicial

    clearScreen();
    print(": : Digite algo:");

    // Configura o handler da interrupção do teclado (0x21)
    set_idt_gate(33, (uint32)keyboard_handler);
    set_idt();

    // Chama a função readStr para obter a entrada do usuário
    updateCursor();
    string userInput = readStr();

    // Limpa a tela e imprime a string lida
    clearScreen();
    print(": : Voce digitou:");
    print(userInput);
    print("\n\nEsperando interrupção do teclado...");

    // Não é necessário chamar asm("int $0x19");
    // O código abaixo só será executado após a interrupção do teclado
    clearScreen();
    print(": : Introducao da interrupcao do teclado!");
}

