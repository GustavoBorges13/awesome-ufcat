#include "basic/include/util.h"

// : : Implementação da função memory_copy : :
void memory_copy(char *source, char *dest, int nbytes) {
    for (int i = 0; i < nbytes; i++) {
        dest[i] = source[i];
    }
}

// : : Implementação da função memory_set : :
void memory_set(uint8 *dest, uint8 val, uint32 len) {
    for (uint32 i = 0; i < len; i++) {
        dest[i] = val;
    }
}

// : : Implementação da função int_to_ascii : :
void int_to_ascii(int n, char str[]) {
    int i = 0, sign = 1;
    
    // Lida com números negativos
    if (n < 0) {
        sign = -1;
        n = -n;
    }
    
    // Converte cada dígito para ASCII e armazena na string
    do {
        str[i++] = n % 10 + '0';
    } while ((n /= 10) > 0);

    // Adiciona sinal negativo se necessário
    if (sign == -1) {
        str[i++] = '-';
    }
    
    // Termina a string
    str[i] = '\0';

    // Inverte a string
    int start = 0;
    int end = i - 1;
    while (start < end) {
        char temp = str[start];
        str[start] = str[end];
        str[end] = temp;
        start++;
        end--;
    }
}

