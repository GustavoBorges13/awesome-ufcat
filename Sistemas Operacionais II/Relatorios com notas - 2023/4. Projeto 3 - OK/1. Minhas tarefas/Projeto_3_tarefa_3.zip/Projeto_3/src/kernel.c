#include "kb.h"
#include "system.h"
#include "idt.h"
#include "isr.h"
#include "string.h"
#include "screen.h"

int kmain()
{
  isr_install();
  clearScreen();

  //int a=5/0; //Para testes

  print("\n------->Basic");
  print("\n	Operating");
  print("\n	System<------- ");

  print("Bem vindo ao B.OS ------->\n\n\n\nEntre um comando\n");

  while(1) 
  {
    print("\nB.OS> ");

    string ch = readStr();

    if(strEql(ch, "cmd"))
    {
      print("\nVoce ja esta no cmd\n");
    }
    else if(strEql(ch, "clear"))
    {
      clearScreen();
    }
    else
    {
      print("\nComando desconhecido!\n");
    }
    print("\n");
  }
}
