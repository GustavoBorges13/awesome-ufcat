#include "util.h"

void memory_copy(char *source, char *dest, int nbytes) {
  int i;
  for (i=0 ; i < nbytes; i++) {
    *(dest + i) = *(source + i); // dest[i] = source[i]
  }
}

void memory_set(uint8 *dest, uint8 val, uint32 len) {
  uint8 *temp = (uint8 *)dest;
  for ( ; len != 0; len--) 
    *temp++ = val;
}

void int_to_ascii(int n, char str[]) {
  int i;

  if (n < 0) // trabalho com qquer número em módulo
    n = -n;

  i = 0;

  do {
    str[i++] = n % 10 + '0'; //5 ---> 5 + '0' = 5 + 48 = 53 que é o ASCII do 5
  } while ((n /= 10) > 0);

  str[i] = '\0'; // para fechar a string de maneira apropriada em C

  /* TODO: implementar o 'reverso' */
}
