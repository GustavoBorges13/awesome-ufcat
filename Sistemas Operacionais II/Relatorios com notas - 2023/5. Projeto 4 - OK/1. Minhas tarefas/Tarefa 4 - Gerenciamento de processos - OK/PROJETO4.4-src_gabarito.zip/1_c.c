#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <errno.h>
#include <ctype.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include "halfduplex.h"		/* For name of the named-pipe */

#define NFORKS 3

typedef struct {
	int             id;
	char            data[MAX_BUF_SIZE];
	int             lastone;
}               PACKET;

int
main(int argc, char *argv[])
{
	pid_t           whichone, reader, w1, w2;
	int             status, howmany, fd, ret_val, count, numread;
	PACKET          r, p1, p2;

	if ((reader = fork()) == 0) {	/* Parent spawns 1st child */
		printf("\nREADER: Hiya, I am the reader child, and my id is %d\n", getpid());

		/* Create the named - pipe */
		ret_val = mkfifo(HALF_DUPLEX, 0666);

		if ((ret_val == -1) && (errno != EEXIST)) {
			perror("\nREADER: Error creating the named pipe");
			exit(1);
		}
		/* Open the pipe for reading */
		fd = open(HALF_DUPLEX, O_RDONLY);

		do {		/* This applies to all the writers */
			/* Read from the pipe */
			read(fd, &r, sizeof(r));
			printf("\nREADER: Read From the pipe: ");
			printf("\n====\n");
			printf("ID: %d\n", r.id);
			printf("MSG: %s\n", r.data);
			printf("\n====\n");
		} while (r.lastone != 0);

		printf("\n");

		printf("\n\n==Reader ends==\n");

		exit(0);

	} else if (reader == -1) {
		perror("\nREADER: something went wrong...\n");
		exit(1);

	} else if ((w1 = fork()) == 0) {	/* Parent spawns 2nd  child */
		printf("\n\nWRITER1: Hiya, I am a writer child, and my id is %d\n", getpid());

		sleep(1);

		/* Open the pipe for writing */
		fd = open(HALF_DUPLEX, O_WRONLY);

		/* Fill the packet */
		p1.id = getpid();
		sprintf(p1.data, "%s %d", "Hiya! I am the writer with ID ", getpid());
		p1.lastone = 1;

		/* Write to the pipe */
		write(fd, &p1, sizeof(p1));

		printf("\n\n==Writer1 ends==\n");

		exit(0);
	} else if (w1 == -1) {
		perror("\nWRITER1: something went wrong...\n");
		exit(1);
	} else if ((w2 = fork()) == 0) {	/* Parent spawns 2nd  child */
		printf("\n\nWRITER2: Hiya, I am the writer child, and my id is %d\n", getpid());

		sleep(1);

		/* Open the pipe for writing */
		fd = open(HALF_DUPLEX, O_WRONLY);

		/* Fill the packet */
		p2.id = getpid();
		sprintf(p2.data, "%s %d", "Hiya! I am the writer with ID ", getpid());
		p2.lastone = 0;

		/* Write to the pipe */
		write(fd, &p2, sizeof(p2));

		printf("\n\n==Writer2 ends==\n");

		exit(2);
	} else if (w2 == -1) {
		perror("\nWRITER2: something went wrong...\n");
		exit(1);
	}
	
	howmany = 0;

	while (howmany < NFORKS) {
		whichone = wait(&status);
		howmany++;

		printf("\nChild exited (%d).\n", whichone);
	}
}
