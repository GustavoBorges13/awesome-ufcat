#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <string.h>
#include "packet.h"

#define PORT        4661

/* REPLACE with your server machine name*/
#define HOST     "localhost"
#define SIZE     8192

main(argc, argv)
int argc; char **argv;
{
        char hostname[100];
	//char    message[SIZE];
	PACKET    message;
	int	sd;
	struct sockaddr_in sin;
	struct sockaddr_in pin;
	struct hostent *hp;

	if (argc <= 2) {
		printf("\nWRITER usage : %s <reader address> <string to be sent to the reader>\n", argv[0]);
		exit(1);
	}

        if (argc > 2)
            { strcpy(hostname,argv[1]); }
        
	strcpy(hostname, HOST);

	/* go find out about the desired host machine */
	if ((hp = gethostbyname(hostname)) == 0) {
		perror("\n\nWRITER: gethostbyname error.\n");
		exit(1);
	}

	/* fill in the socket structure with host information */
	memset(&pin, 0, sizeof(pin));
	pin.sin_family = AF_INET;
	pin.sin_addr.s_addr = ((struct in_addr *)(hp->h_addr))->s_addr;
	pin.sin_port = htons(PORT);
	
	/* fill in the message structure */
	message.id = getpid();
	sprintf(message.data, "%s", argv[2], getpid());

	if(!strcmp(argv[2], "exit"))
		message.lastone = 1;
	else 
		message.lastone = 0;
		

	/* grab an Internet domain socket */
	if ((sd = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
		perror("\n\nWRITER: socket error.\n");
		exit(1);
	}

	/* connect to PORT on HOST */
	if (connect(sd,(struct sockaddr *)  &pin, sizeof(pin)) == -1) {
		perror("\n\nWRITER: connect error.\n");
		exit(1);
	}

	/* send a message to the server PORT on machine HOST */
	//if (send(sd, argv[2], strlen(argv[2]), 0) == -1) {
	if (send(sd, &message, sizeof(message), 0) == -1) {
		perror("\n\n WRITER: send.\n");
		exit(1);
	}

        //printf("\n\nWRITER: message to be sent is [%s].\n", argv[2]);
        printf("\n\nWRITER: message to be sent is [%s].\n", message.data);

        /* wait for a message to come back from the server */
        if (recv(sd, &message, SIZE, 0) == -1) {
                perror("\n\nWRITER: recv error.\n");
                exit(1);
        }

        /* spew-out the results and bail out of here! */
        //printf("\n\nWRITER: message received is [%s].\n", message);
        printf("\n\nWRITER: overall message sent is: ");
	
	printf("\nMESSAGE:\n");
        printf("\n====\n");
        printf("ID: %d\n", message.id);
        printf("MSG: [%s]\n", message.data);
        printf("\n====\n");
        printf("\nEND MESSAGE:\n");

	close(sd);
}

 
