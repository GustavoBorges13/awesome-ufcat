#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

#define NFORKS 10

void
do_nothing (int retval)
{
	printf("CHILD: Parent: %d || Child pid: %d\n", getppid(), getpid());
	sleep(10);
	exit (retval);
}

int
main (int argc, char *argv[])
{
	pid_t whichone, pid[NFORKS];
	int j, status, howmany;

	for (j = 0; j < NFORKS; j++)
	{

		if ((pid [j] = fork ()) < 0)
		{
			printf ("PARENT: fork failed with error code= %d\n", pid[j]);
			exit (1);
		}

		if (pid[j] == 0)
		{
			do_nothing (j);
		}
	}

	howmany = 0;
	while (howmany < NFORKS)
	{
		/*
		 * waitpid (pid[j], &status, 0);
		 */
		whichone = wait(&status);
		howmany++;

		printf("PARENT: Child exited (%d).\n", whichone);
		printf("PARENT: Child's exit code is: %d\n", WEXITSTATUS(status));
	}
}
