#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <stdatomic.h> // Biblioteca para operações atômicas
#include <stdint.h>    // Para usar intptr_t

int counter = 0; // Variável compartilhada inicializada
atomic_flag lock = ATOMIC_FLAG_INIT; // Variável atômica para o lock

// Função para entrar na seção crítica
void enterSC(int i) {
    while (atomic_flag_test_and_set(&lock)) {
        // Laço para travar a seção crítica
    }
    return;
}

// Função para sair da seção crítica
void leaveSC(int i) {
    atomic_flag_clear(&lock); // Libera a seção crítica
    return;
}

// Função executada pelas threads
void* cria(void* arg) {
    int aux = (intptr_t)arg; // Converte o argumento para inteiro de maneira segura

    // Entra na seção crítica
    enterSC(aux);
    printf("\nP%d: A região crítica é minha!!!\n", aux);
    counter++;
    printf("\nP%d: counter = %d\n\n", aux, counter);
    leaveSC(aux); // Sai da seção crítica

    return NULL;
}

// Função para verificar erros na criação das threads
void verifica_erro(int resultado) {
    if (resultado != 0) {
        printf("Algum erro ocorreu na criação das threads!\n");
        exit(1);
    }
}

int main(void) {
    pthread_t thi, thj; // Variáveis para as threads

    // Criação das threads com verificação de erros
    verifica_erro(pthread_create(&thi, NULL, cria, (void*)0));
    verifica_erro(pthread_create(&thj, NULL, cria, (void*)1));

    // Espera as threads terminarem
    pthread_join(thi, NULL);
    pthread_join(thj, NULL);

    return 0;
}
