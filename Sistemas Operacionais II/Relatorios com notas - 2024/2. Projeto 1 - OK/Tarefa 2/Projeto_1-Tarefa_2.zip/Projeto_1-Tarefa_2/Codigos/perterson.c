#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <stdbool.h>  // Para usar true e false
#include <stdint.h>   // Para usar intptr_t no cast de ponteiros

#define NUM_THREADS 2

bool flag[NUM_THREADS]; 
int turn, counter = 0;

void enterSC(int i) {
    int j = 1 - i;  // J é o oposto de i
    flag[i] = true; // Thread solicita entrada na seção crítica
    turn = j;
    while (flag[j] && turn == j);  // Laço para segurar a seção crítica
}

void leaveSC(int i) {
    flag[i] = false;  // Thread sai da seção crítica
}

void *cria(void *arg) {
    int aux = (intptr_t)arg;  // Converte para inteiro
    enterSC(aux);  // Entra na seção crítica
    printf("P%d: A região crítica é minha!!!\n", aux);
    counter++;
    printf("P%d: counter = %d\n", aux, counter);
    leaveSC(aux);  // Sai da seção crítica
    return NULL;
}

int main(void) {
    pthread_t threads[NUM_THREADS];

    // Criação das threads
    for (int i = 0; i < NUM_THREADS; i++) {
        if (pthread_create(&threads[i], NULL, cria, (void *)(intptr_t)i) != 0) {
            fprintf(stderr, "Erro ao criar a thread %d\n", i);
            exit(1);
        }
    }

    // Aguarda as threads
    for (int i = 0; i < NUM_THREADS; i++) {
        if (pthread_join(threads[i], NULL) != 0) {
            fprintf(stderr, "Erro ao aguardar a thread %d\n", i);
        }
    }

    return 0;
}
