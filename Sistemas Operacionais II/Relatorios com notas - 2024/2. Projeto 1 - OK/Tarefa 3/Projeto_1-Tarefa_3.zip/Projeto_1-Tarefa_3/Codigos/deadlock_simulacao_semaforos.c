#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
#include <unistd.h>
#include <semaphore.h>

pthread_t tid[2];
sem_t S, Q; // Semáforos S e Q, representando os recursos compartilhados

void* P0(void* arg) {
    printf("P0 tentando adquirir o recurso S...\n"); // Debug
    sem_wait(&S); // P0 adquire o semáforo S
    printf("P0 adquiriu o recurso S.\n"); // Debug
    sleep(1);     // Simula processamento
    printf("P0 tentando adquirir o recurso Q...\n"); // Debug
    sem_wait(&Q); // P0 tenta adquirir Q, mas já foi adquirido por P1
    printf("P0 adquiriu o recurso Q.\n"); // Debug

    // Código crítico
    printf("P0 entrou na região crítica.\n");

    sem_post(&Q); // Libera Q
    printf("P0 liberou o recurso Q.\n"); // Debug
    sem_post(&S); // Libera S
    printf("P0 liberou o recurso S.\n"); // Debug
    return NULL;
}

void* P1(void* arg) {
    printf("P1 tentando adquirir o recurso Q...\n"); // Debug
    sem_wait(&Q); // P1 adquire o semáforo Q
    printf("P1 adquiriu o recurso Q.\n"); // Debug
    sleep(1);     // Simula processamento
    printf("P1 tentando adquirir o recurso S...\n"); // Debug
    sem_wait(&S); // P1 tenta adquirir S, mas já está ocupado por P0
    printf("P1 adquiriu o recurso S.\n"); // Debug

    // Código crítico
    printf("P1 entrou na região crítica.\n");

    sem_post(&S); // Libera S
    printf("P1 liberou o recurso S.\n"); // Debug
    sem_post(&Q); // Libera Q
    printf("P1 liberou o recurso Q.\n"); // Debug
    return NULL;
}

int main() {
    sem_init(&S, 0, 1); // Inicializa o semáforo S com valor 1 (recurso disponível)
    sem_init(&Q, 0, 1); // Inicializa o semáforo Q com valor 1 (recurso disponível)

    pthread_create(&tid[0], NULL, P0, NULL); // Cria a thread P0
    pthread_create(&tid[1], NULL, P1, NULL); // Cria a thread P1

    pthread_join(tid[0], NULL); // Aguarda P0 terminar
    pthread_join(tid[1], NULL); // Aguarda P1 terminar

    sem_destroy(&S); // Destrói o semáforo S
    sem_destroy(&Q); // Destrói o semáforo Q

    return 0;
}