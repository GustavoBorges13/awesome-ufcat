#include <pthread.h>
#include <semaphore.h>
#include <stdio.h>
#include <unistd.h>

#define N 5                    // Número de filósofos
#define LEFT (i+N-1)%N         // Número do vizinho à esquerda de i
#define RIGHT (i+1)%N          // Número do vizinho à direita de i
#define THINKING 0             // O filósofo está pensando
#define HUNGRY 1               // O filósofo está tentando pegar garfos
#define EATING 2               // O filósofo está comendo

int state[N];                  // Estado de cada filósofo
sem_t mutex;                   // Exclusão mútua para as regiões críticas
sem_t s[N];                    // Um semáforo por filósofo

void think(int i) {
    printf("Filósofo %d está pensando.\n", i);
    sleep(1); // Simula tempo pensando
}

void eat(int i) {
    printf("Filósofo %d está comendo.\n", i);
    sleep(2); // Simula tempo comendo
}

void test(int i) {
    if (state[i] == HUNGRY && state[LEFT] != EATING && state[RIGHT] != EATING) {
        state[i] = EATING;
        printf("Filósofo %d pegou os garfos e está comendo.\n", i);
        sem_post(&s[i]); // Libera o filósofo para comer
    }
}

void take_forks(int i) {
    sem_wait(&mutex); // Entra na região crítica
    state[i] = HUNGRY;
    printf("Filósofo %d está com fome.\n", i);
    test(i);          // Tenta pegar os garfos
    sem_post(&mutex); // Sai da região crítica
    sem_wait(&s[i]);  // Bloqueia se os garfos não foram pegos
}

void put_forks(int i) {
    sem_wait(&mutex); // Entra na região crítica
    state[i] = THINKING;
    printf("Filósofo %d devolveu os garfos e está pensando.\n", i);
    test(LEFT);       // Permite que o vizinho à esquerda coma
    test(RIGHT);      // Permite que o vizinho à direita coma
    sem_post(&mutex); // Sai da região crítica
}

void* philosopher(void* num) {
    int i = *(int*)num;
    while (1) {
        //printf("Filósofo %d está iniciando o ciclo.\n", i); // Indica o início do ciclo
        think(i);       // O filósofo está pensando
        take_forks(i);  // Pega os garfos ou bloqueia
        eat(i);         // Come
        put_forks(i);   // Devolve os garfos à mesa
        //printf("Filósofo %d terminou o ciclo.\n", i); // Indica o fim do ciclo
    }
    return NULL;
}

int main() {
    pthread_t threads[N];
    int phil[N];

    // Inicializa semáforos e estados
    sem_init(&mutex, 0, 1);
    for (int i = 0; i < N; i++) {
        sem_init(&s[i], 0, 0);
        state[i] = THINKING;
        phil[i] = i;
    }

    // Cria threads para cada filósofo
    for (int i = 0; i < N; i++) {
        pthread_create(&threads[i], NULL, philosopher, &phil[i]);
    }

    // Junta as threads (nunca termina)
    for (int i = 0; i < N; i++) {
        pthread_join(threads[i], NULL);
    }

    // Destrói semáforos (nunca alcançado, mas seria necessário em um sistema real)
    sem_destroy(&mutex);
    for (int i = 0; i < N; i++) {
        sem_destroy(&s[i]);
    }

    return 0;
}