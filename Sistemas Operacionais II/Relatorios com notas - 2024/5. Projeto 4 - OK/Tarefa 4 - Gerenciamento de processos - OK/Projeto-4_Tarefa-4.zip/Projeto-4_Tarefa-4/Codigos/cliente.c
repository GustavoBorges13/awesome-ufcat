#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <string.h>

#define PORT 4661

/* Substitua pelo endereço do servidor */
#define HOST "localhost"
#define SIZE 8192

typedef struct {
    int id;
    char data[SIZE];
    int lastone;
} PACKET;

int main(int argc, char **argv)
{
    char hostname[100];
    PACKET message;
    int sd;
    struct sockaddr_in sin, pin;
    struct hostent *hp;

    if (argc <= 2) {
        printf("\nUSO: %s <endereço do leitor> <mensagem a ser enviada>\n", argv[0]);
        exit(1);
    }

    if (argc > 2) {
        strcpy(hostname, argv[1]);
    } else {
        strcpy(hostname, HOST);
    }

    /* Obtendo informações sobre o servidor */
    if ((hp = gethostbyname(hostname)) == 0) {
        perror("\n\nERRO: Falha ao obter nome do host.\n");
        exit(1);
    }

    /* Configurando a estrutura do socket */
    memset(&pin, 0, sizeof(pin));
    pin.sin_family = AF_INET;
    pin.sin_addr.s_addr = ((struct in_addr *)(hp->h_addr))->s_addr;
    pin.sin_port = htons(PORT);
    
    /* Preenchendo a estrutura da mensagem */
    message.id = getpid();
    sprintf(message.data, "%s", argv[2], getpid());

    if (!strcmp(argv[2], "exit"))
        message.lastone = 1;
    else 
        message.lastone = 0;
        
    /* Criando um socket de domínio da Internet */
    if ((sd = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
        perror("\n\nERRO: Falha ao criar socket.\n");
        exit(1);
    }

    /* Conectando-se ao servidor */
    if (connect(sd, (struct sockaddr *)  &pin, sizeof(pin)) == -1) {
        perror("\n\nERRO: Falha ao conectar.\n");
        exit(1);
    }

    /* Enviando mensagem para o servidor */
    if (send(sd, &message, sizeof(message), 0) == -1) {
        perror("\n\nERRO: Falha ao enviar mensagem.\n");
        exit(1);
    }

    printf("MENSAGEM ENVIADA: [%s].\n", message.data);

    /* Aguardando resposta do servidor */
    if (recv(sd, &message, SIZE, 0) == -1) {
        perror("\n\nERRO: Falha ao receber resposta.\n");
        exit(1);
    }

    /* Exibindo mensagem recebida */
    printf("\nMENSAGEM RECEBIDA DO SERVIDOR:\n");
    printf("\n====\n");
    printf("ID: %d\n", message.id);
    printf("MSG: [%s]\n", message.data);
    printf("====\n");

    /* Fechando a conexão */
    close(sd);
}
