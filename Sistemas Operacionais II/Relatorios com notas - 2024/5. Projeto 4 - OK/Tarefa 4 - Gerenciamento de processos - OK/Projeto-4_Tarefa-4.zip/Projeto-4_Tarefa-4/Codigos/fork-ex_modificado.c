#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

#define NFORKS 10  // Criamos 10 processos filhos

void do_nothing() {
    printf("Processo filho criado! PID: %d || Pai: %d\n", getpid(), getppid());
    sleep(10);  // Mantém o processo ativo para podermos visualizar no `ps`
    exit(0);
}

int main(int argc, char *argv[]) {
    int pid[NFORKS], j, status, completed_processes = 0;
    pid_t terminated_pid;

    for (j = 0; j < NFORKS; j++) {
        pid[j] = fork();

        if (pid[j] < 0) {
            printf("Erro ao criar o processo filho.\n");
            exit(1);
        }

	if (pid[j] == 0) {  // Processo filho
            do_nothing();
	}
    }

    // Esperando os processos filhos finalizarem
    while (completed_processes < NFORKS) {
        terminated_pid = wait(&status);
        completed_processes++;

        printf("Processo filho finalizado (%d).\n", terminated_pid);
    }

    return 0;
}
