#ifndef HALF_DUPLEX_H
#define HALF_DUPLEX_H

#define HALF_DUPLEX "/tmp/halfduplex" // Caminho do FIFO
#define MAX_BUF_SIZE 256              // Tamanho do buffer de mensagem

#endif
