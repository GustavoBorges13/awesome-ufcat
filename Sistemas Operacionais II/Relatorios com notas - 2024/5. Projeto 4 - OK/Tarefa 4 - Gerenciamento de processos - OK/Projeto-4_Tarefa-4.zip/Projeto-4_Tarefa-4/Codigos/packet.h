X_BUF_SIZE	255

typedef struct {
	int id;
	char data[MAX_BUF_SIZE];
	int lastone;
} PACKET;
