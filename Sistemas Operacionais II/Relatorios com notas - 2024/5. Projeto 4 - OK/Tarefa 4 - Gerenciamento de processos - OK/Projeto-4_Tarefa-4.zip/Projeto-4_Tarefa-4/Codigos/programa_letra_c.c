#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include "halfduplex.h"

#define NFORKS 3

typedef struct {
    int id;
    char data[MAX_BUF_SIZE];
    int lastone;
} PACKET;

int main(int argc, char *argv[]) {
    pid_t reader, w1, w2, terminated_pid;
    int status, completed_processes = 0, fd, ret_val;
    PACKET r, p1, p2;

    if ((reader = fork()) == 0) {
        printf("\nREADER: Processo leitor iniciado, PID: %d\n", getpid());

        ret_val = mkfifo(HALF_DUPLEX, 0666);
        if ((ret_val == -1) && (errno != EEXIST)) {
            perror("\nREADER: Erro ao criar FIFO");
            exit(1);
        }

        fd = open(HALF_DUPLEX, O_RDONLY);
        while (1) {
            read(fd, &r, sizeof(r));
            printf("\nREADER: Mensagem recebida:\n====\nID: %d\nMSG: %s\n====\n", r.id, r.data);
            if (r.lastone == 0) break;
        }

        printf("\n== Leitor finalizado ==\n");
        exit(0);
    } else if (reader == -1) {
        perror("\nREADER: Erro ao criar processo leitor\n");
        exit(1);
    }

    if ((w1 = fork()) == 0) {
        printf("\n\nWRITER1: Processo escritor iniciado, PID: %d\n", getpid());
        sleep(1);
        fd = open(HALF_DUPLEX, O_WRONLY);

        p1.id = getpid();
        sprintf(p1.data, "Mensagem do escritor %d", getpid());
        p1.lastone = 1;

        write(fd, &p1, sizeof(p1));
        printf("\n\n== Writer1 finalizado ==\n");
        exit(0);
    } else if (w1 == -1) {
        perror("\nWRITER1: Erro ao criar processo escritor\n");
        exit(1);
    }

    if ((w2 = fork()) == 0) {
        printf("\n\nWRITER2: Processo escritor iniciado, PID: %d\n", getpid());
        sleep(1);
        fd = open(HALF_DUPLEX, O_WRONLY);

        p2.id = getpid();
        sprintf(p2.data, "Mensagem do escritor %d", getpid());
        p2.lastone = 0;

        write(fd, &p2, sizeof(p2));
        printf("\n\n== Writer2 finalizado ==\n");
        exit(0);
    } else if (w2 == -1) {
        perror("\nWRITER2: Erro ao criar processo escritor\n");
        exit(1);
    }

    while (completed_processes < NFORKS) {
        terminated_pid = wait(&status);
        completed_processes++;
        printf("\nProcesso finalizado (%d).\n", terminated_pid);
    }
    return 0;
}