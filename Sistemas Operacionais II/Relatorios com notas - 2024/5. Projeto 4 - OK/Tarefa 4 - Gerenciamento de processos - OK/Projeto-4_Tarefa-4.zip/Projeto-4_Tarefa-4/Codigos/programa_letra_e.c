#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

#define NFORKS 10  // Criamos 10 processos filhos

void do_nothing(int exit_status) {
    printf("Processo filho criado! PID: %d || Pai: %d || Status de saída: %d\n", getpid(), getppid(), exit_status);
    sleep(2);  // Mantém o processo ativo por um tempo
    exit(exit_status);
}

int main() {
    int pid[NFORKS], j, status, completed_processes = 0;
    pid_t terminated_pid;

    for (j = 0; j < NFORKS; j++) {
        pid[j] = fork();

        if (pid[j] < 0) {
            printf("Erro ao criar o processo filho.\n");
            exit(1);
        }

        if (pid[j] == 0) {  // Processo filho
            do_nothing(j + 1); // Cada filho tem um status de saída diferente
        }
    }

    // Esperando os processos filhos finalizarem
    while (completed_processes < NFORKS) {
        terminated_pid = wait(&status);
        if (WIFEXITED(status)) { // Verifica se o processo terminou normalmente
            printf("Processo filho (%d) finalizado com status: %d\n", terminated_pid, WEXITSTATUS(status));
        } else {
            printf("Processo filho (%d) não terminou normalmente.\n", terminated_pid);
        }
        completed_processes++;
    }

    return 0;
}
