#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <string.h>
#include <arpa/inet.h>

#define PORT 4661
#define SIZE 8192

typedef struct {
    int id;
    char data[SIZE];
    int lastone;
} PACKET;

int main() {
    PACKET message;
    int sd, sd_current;
    socklen_t addrlen;
    struct sockaddr_in sin, pin;

    if ((sd = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
        perror("socket");
        exit(1);
    }

    memset(&sin, 0, sizeof(sin));
    sin.sin_family = AF_INET;
    sin.sin_addr.s_addr = INADDR_ANY;
    sin.sin_port = htons(PORT);

    if (bind(sd, (struct sockaddr *)&sin, sizeof(sin)) == -1) {
        perror("bind");
        exit(1);
    }

    if (listen(sd, 5) == -1) {
        perror("Erro ao ouvir conexões");
        exit(1);
    }

    printf("Servidor escutando na porta %d...\n", PORT);

    do {
        addrlen = sizeof(pin);
        if ((sd_current = accept(sd, (struct sockaddr *)&pin, &addrlen)) == -1) {
            perror("Erro ao aceitar conexão");
            exit(1);
        }

        printf("Conectado com %s\n", inet_ntoa(pin.sin_addr));
        printf("Vindo da porta %d\n", ntohs(pin.sin_port));

        if (recv(sd_current, &message, sizeof(message), 0) == -1) {
            perror("Erro ao receber mensagem");
            exit(1);
        }

        printf("\nMENSAGEM RECEBIDA:\n====\nID: %d\nMSG: [%s]\n====\n", message.id, message.data);

        if (send(sd_current, &message, sizeof(message), 0) == -1) {
            perror("Erro ao enviar mensagem de volta");
            exit(1);
        }

        close(sd_current); // Fecha a conexão com o cliente antes de continuar
    } while (message.lastone != 1);

    close(sd);
    return 0;
}
